Pierre Dibo et Oulebsir Hocine

Compilation : 

make all

Execution:

ocamlrun automate <file_name> <time : float> <number_of_next_gen>


