int execute_command_redirect(int argc, char** argv);
